package com.acme.fw.data;

public enum Role {
    USER, ADMIN;
}
