@NonNullApi
package com.acme.fw.data;

import org.springframework.lang.NonNullApi;
