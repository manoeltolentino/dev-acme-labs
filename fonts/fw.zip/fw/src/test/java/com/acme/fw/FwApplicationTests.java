package com.acme.fw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FwApplicationTests {

	@Test
	void contextLoads() {
	}

}
