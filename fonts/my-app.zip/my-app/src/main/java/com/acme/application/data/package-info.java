@NonNullApi
package com.acme.application.data;

import org.springframework.lang.NonNullApi;
