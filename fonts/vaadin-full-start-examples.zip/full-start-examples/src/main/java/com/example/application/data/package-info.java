@NonNullApi
package com.example.application.data;

import org.springframework.lang.NonNullApi;
