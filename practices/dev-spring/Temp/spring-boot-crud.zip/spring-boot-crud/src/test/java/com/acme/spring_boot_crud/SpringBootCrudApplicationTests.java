package com.acme.spring_boot_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
